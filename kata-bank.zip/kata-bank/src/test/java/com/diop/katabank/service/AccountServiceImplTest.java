package com.diop.katabank.service;

import com.diop.katabank.domain.Account;
import com.diop.katabank.dto.AccountDto;
import com.diop.katabank.dto.OperationDto;
import com.diop.katabank.enumeration.AccountType;
import com.diop.katabank.enumeration.OperationType;
import com.diop.katabank.exception.BankBusinessException;
import com.diop.katabank.repository.AccountRepository;
import com.diop.katabank.repository.OperationRepository;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.util.ReflectionTestUtils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;


@DataJpaTest
class AccountServiceImplTest {

    @Autowired
    AccountRepository accountRepository;
    @Autowired
    OperationRepository operationRepository;
    AccountServiceImpl accountService = new AccountServiceImpl(accountRepository, operationRepository);

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(accountService, "accountRepository", accountRepository);
        ReflectionTestUtils.setField(accountService, "operationRepository", operationRepository);
    }

    @Test
    @DisplayName("should not deposit amount when operation type is different DEPOSIT")
    public void t1() {

        Account account = buildAccount(BigDecimal.ZERO);
        UUID id = accountRepository.save(account).getId();

        assertThatThrownBy(() -> {
            accountService.depositMoney(id, OperationDto.builder().amount(BigDecimal.TEN).operationType(OperationType.WITHDRAWL).build());

        }).isInstanceOf(BankBusinessException.class)

                .hasMessage("operation type is not DEPOSIT");


    }

    @Test
    @DisplayName("should deposit amount")
    public void t2() {
        //given
        Account account = buildAccount(BigDecimal.ZERO);
        UUID id = accountRepository.save(account).getId();

        //when
        AccountDto result = accountService.depositMoney(id, OperationDto.builder().amount(BigDecimal.TEN).operationType(OperationType.DEPOSIT).build());

        //then
        assertThat(result.getBalance()).isEqualTo(BigDecimal.TEN);
    }


    @Test
    @DisplayName("should not withDrawal amount when operation type is different DEPOSIT")
    public void t3() {
        //given
        Account account = buildAccount(BigDecimal.ZERO);
        UUID id = accountRepository.save(account).getId();

        // when and then
        assertThatThrownBy(() -> {
            accountService.withDrawalMoney(id, OperationDto.builder().amount(BigDecimal.TEN).operationType(OperationType.DEPOSIT).build());

        }).isInstanceOf(BankBusinessException.class)

                .hasMessage("operation type is not WITHDRAWL");


    }

    @Test
    @DisplayName("should not withDrawal amount when insufficient balance")
    public void t4() {
        //given
        Account account = buildAccount(BigDecimal.ZERO);
        UUID id = accountRepository.save(account).getId();

        //when and then
        assertThatThrownBy(() -> {
            accountService.withDrawalMoney(id, OperationDto.builder().amount(BigDecimal.TEN).operationType(OperationType.WITHDRAWL).build());

        }).isInstanceOf(BankBusinessException.class)

                .hasMessage("insufficient balance -10");

    }

    @Test
    @DisplayName("should withDraw amount")
    public void t5() {
        // given
        Account account = buildAccount(BigDecimal.TEN);
        UUID id = accountRepository.save(account).getId();

        //when
        AccountDto result = accountService.withDrawalMoney(id, OperationDto.builder().amount(BigDecimal.ONE).operationType(OperationType.WITHDRAWL).build());

        //then
        assertThat(result.getBalance()).isEqualTo(BigDecimal.valueOf(9));
    }

    private Account buildAccount(BigDecimal balance) {
        return Account.builder()
                .accountType(AccountType.CLASSIC)
                .address("france")
                .number("123")
                .createAt(ZonedDateTime.now())
                .balance(balance)
                .operations(new ArrayList<>())
                .build();
    }
}

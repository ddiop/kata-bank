package com.diop.katabank.repository;



import com.diop.katabank.domain.Operation;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OperationRepository extends JpaRepository<Operation, UUID> {
    List<Operation> findAllByAccount_Id(UUID accountId);
}

package com.diop.katabank.enumeration;

public enum AccountType {
    PRO("pro"),
    CLASSIC("classic");

    private String value;


    AccountType(String value) {
        this.value = value;
    }
}

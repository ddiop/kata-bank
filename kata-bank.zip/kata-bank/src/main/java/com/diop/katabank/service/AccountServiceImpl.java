package com.diop.katabank.service;

;
import com.diop.katabank.domain.Account;
import com.diop.katabank.domain.Operation;
import com.diop.katabank.dto.AccountDto;
import com.diop.katabank.dto.OperationDto;
import com.diop.katabank.enumeration.OperationType;
import com.diop.katabank.exception.BankBusinessException;
import com.diop.katabank.repository.AccountRepository;
import com.diop.katabank.repository.OperationRepository;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Slf4j
public class AccountServiceImpl implements AccountService {
    private final AccountRepository accountRepository;
    private final OperationRepository operationRepository;

    public AccountServiceImpl(AccountRepository accountRepository, OperationRepository operationRepository) {
        this.accountRepository = accountRepository;
        this.operationRepository = operationRepository;
    }

    @Override
    @Transactional(rollbackFor = BankBusinessException.class)
    public AccountDto depositMoney(UUID accountId, OperationDto operation) {
        boolean isDeposit = operation.getOperationType() == OperationType.DEPOSIT;
        if (!isDeposit) {
            throw new BankBusinessException("operation type is not DEPOSIT");
        }

        Account account = accountRepository.findById(accountId).orElseThrow(() -> new BankBusinessException(String.format("account %s not found ", accountId)));

        BigDecimal oldAmount = account.getBalance();
        operation.setCreateAt(ZonedDateTime.now());
        operation.setBalance(oldAmount);
        Operation saveOperation = operationRepository.save(dtoToOperation(operation));

        account.getOperations().add(saveOperation);
        BigDecimal newBalance = oldAmount.add(operation.getAmount());
        account.setBalance(newBalance);
        Account save = accountRepository.save(account);

        saveOperation.setAccount(save);
        operationRepository.save(saveOperation);

        return accountToDto(save);

    }

    @Override
    @Transactional(rollbackFor = BankBusinessException.class)
    public AccountDto withDrawalMoney(UUID accountId, OperationDto operation) {
        boolean isWithDraw = OperationType.WITHDRAWL == operation.getOperationType();
        if (!isWithDraw) {
            throw new BankBusinessException("operation type is not WITHDRAWL");
        }

        Account account = accountRepository.findById(accountId).orElseThrow(() -> new BankBusinessException(String.format("account %s not found ", accountId)));

        BigDecimal oldAmount = account.getBalance();
        BigDecimal newAmount = oldAmount.subtract(operation.getAmount());
        checkInsufficientBalance(newAmount);
        operation.setCreateAt(ZonedDateTime.now());
        operation.setBalance(oldAmount);
        Operation saveOperation = operationRepository.save(dtoToOperation(operation));

        account.getOperations().add(saveOperation);
        account.setBalance(newAmount);
        Account save = accountRepository.save(account);

        saveOperation.setAccount(save);
        operationRepository.save(saveOperation);
        return accountToDto(save);
    }

    @Override
    public List<OperationDto> findAllOperationByAccountId(UUID id) {
        return operationRepository.findAllByAccount_Id(id).stream().map(this::operationToDto).collect(Collectors.toList());
    }

    protected void checkInsufficientBalance(BigDecimal amountResult) {
        if (amountResult.compareTo(BigDecimal.ZERO) < 0) {
            throw new BankBusinessException(String.format("insufficient balance %s", amountResult));
        }
    }

    private OperationDto operationToDto(Operation operation) {

        return OperationDto.builder()
                .accountId(operation.getAccount().getId())
                .amount(operation.getAmount())
                .createAt(operation.getCreateAt())
                .balance(operation.getBalance())
                .operationId(operation.getId())
                .operationType(operation.getOperationType())
                .build();
    }

    private Operation dtoToOperation(OperationDto hop) {
        return Operation.builder()
                .amount(hop.getAmount())
                .balance(hop.getBalance())
                .createAt(hop.getCreateAt())
                .operationType(hop.getOperationType())
                .build();
    }

    private AccountDto accountToDto(Account a) {
        return AccountDto.builder()
                .id(a.getId())
                .number(a.getNumber())
                .createAt(a.getCreateAt())
                .balance(a.getBalance())
                .accountType(a.getAccountType())
                .operations(a.getOperations().stream().map(this::operationToDto).collect(Collectors.toList()))
                .build();
    }
}

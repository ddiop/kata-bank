package com.diop.katabank.dto;

import com.diop.katabank.enumeration.OperationType;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Builder
@Getter
@Setter
public class OperationDto {
    private UUID operationId;
    private ZonedDateTime createAt;
    private BigDecimal amount;
    private BigDecimal balance;
    private OperationType operationType;
    private UUID accountId;
}

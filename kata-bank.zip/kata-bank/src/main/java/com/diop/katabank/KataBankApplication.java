package com.diop.katabank;

import com.diop.katabank.domain.Account;
import com.diop.katabank.domain.Bank;
import com.diop.katabank.domain.Customer;

import com.diop.katabank.enumeration.AccountType;
import com.diop.katabank.repository.AccountRepository;
import com.diop.katabank.repository.CustomerRepository;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Arrays;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@Slf4j
public class KataBankApplication implements CommandLineRunner {
	private final AccountRepository accountRepository;
	private final CustomerRepository customerRepository;


	public KataBankApplication(AccountRepository accountRepository, CustomerRepository customerRepository) {
		this.accountRepository = accountRepository;


		this.customerRepository = customerRepository;
		log.info("save");
	}

	@Override
	public void run(String... args) {
		Account account = Account.builder()
				.accountType(AccountType.CLASSIC)
				.address("france")
				.number("123")
				.createAt(ZonedDateTime.now())
				.balance(BigDecimal.ZERO)
				.build();
		log.info(accountRepository.save(account).getId().toString());
		Bank bank = Bank.builder().name("sg").accounts(Arrays.asList(account)).build();

		Customer customer = Customer.builder()
				.accounts(Arrays.asList(account))
				.firstName("jon")
				.lastName("dho")
				.dateOfBirth(LocalDate.now())

				.build();
		customerRepository.save(customer);

	}


	public static void main(String[] args) {
		SpringApplication.run(KataBankApplication.class, args);
	}


}

package com.diop.katabank.domain;



import com.diop.katabank.enumeration.AccountType;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "account")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Account {
    @Id
    @GeneratedValue
    private UUID id;
    @Column(name = "createAt", columnDefinition = "TIMESTAMP")
    private ZonedDateTime createAt;
    private String number;
    private String address;
    private BigDecimal balance;
    private AccountType accountType;
    @OneToMany(cascade = CascadeType.PERSIST, mappedBy = "account")
    private List<Operation> operations= new ArrayList<>();
}

package com.diop.katabank.enumeration;

public enum OperationType {
    DEPOSIT,
    WITHDRAWL;
}

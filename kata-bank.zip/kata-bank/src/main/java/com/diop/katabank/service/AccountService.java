package com.diop.katabank.service;


;
import com.diop.katabank.dto.AccountDto;
import com.diop.katabank.dto.OperationDto;
import java.util.List;
import java.util.UUID;

public interface AccountService {
    AccountDto depositMoney(UUID accountId, OperationDto operation);

    AccountDto withDrawalMoney(UUID accountId, OperationDto operation);

    List<OperationDto> findAllOperationByAccountId(UUID id);
}

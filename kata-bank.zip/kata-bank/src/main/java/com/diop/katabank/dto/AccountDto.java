package com.diop.katabank.dto;


import com.diop.katabank.enumeration.AccountType;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;
import javax.persistence.Column;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;



@Builder
@Getter
@Setter
public class AccountDto {
    private UUID id;
    @Column(name = "createAt", columnDefinition = "TIMESTAMP")
    private ZonedDateTime createAt;
    private String number;
    private String address;
    private BigDecimal balance;
    private AccountType accountType;
    private List<OperationDto> operations;
}
